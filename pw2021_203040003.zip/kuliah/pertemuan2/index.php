<?php
/*
M. Faishal Thariqulhaq
203040003
https://github.com/FaishalThaariq12/pw2021_203040003
Pertemuan 2 - 11 Februarari 2021
Mempelajari mengenai Sintaks Dasar PHP
*/
?>
<?php
// Standar Output
// echo, print
?>