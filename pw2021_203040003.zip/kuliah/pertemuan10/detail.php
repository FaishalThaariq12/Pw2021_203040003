<?php
require 'function.php';

// ambil id dari link
$id = $_GET['id'];

// query berdasarkan id
$m = query("SELECT * FROM mahasiswa WHERE id = $id ");
?>

<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Document</title>
</head>

<body>
  <h3>Detail mahasiswa</h3>
  <ul>
    <li><img src="img/<?= $m['gambar']; ?>" alt="" style="height:150px;"></li>
    <li>ID : <?= $m['id']; ?></li>
    <li>Nama : <?= $m['nama']; ?></li>
    <li>Email : <?= $m['email']; ?></li>
    <li>Universitas : <?= $m['universitas']; ?></li>
    <li><a href="">ubah</a> | <a href="">hapus</a></li>
    <li><a href="latihan3.php">kembali kedaftar mahasiswa</a></li>
  </ul>
</body>

</html>