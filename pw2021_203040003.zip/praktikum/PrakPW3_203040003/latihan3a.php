<?php 
// Nama :M. Faishal Thariqulhaq
// NRP : 203040003
// Shift : Rabu pukul 09:00-10:00 WIB
?>

<?php
$pengertian = 
        ["ada", 
        "abel", 
        "men", 
        "pung", 
        "nilai"];

echo "Array $pengertian[0]lah suatu vari$pengertian[1] yang dapat $pengertian[2]am$pengertian[3] banyak $pengertian[4]";
?>