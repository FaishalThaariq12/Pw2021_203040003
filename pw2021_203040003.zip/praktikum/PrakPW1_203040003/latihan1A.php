<!-- 
    Nama :M. Faishal Thariqulhaq
    NRP : 20304003
    Shift : Rabu pukul 09:00-10:00 WIB
-->

<?php for ($x=1; $x<=3; $x++){
    for ($z=1; $z<=3; $z++){
        echo "Ini perulangan ke ($x,$z)<br>";
    }
}
?>
